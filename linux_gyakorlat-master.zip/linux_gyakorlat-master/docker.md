# Docker konténer indítása

1. Terminál indítása a hoszt gépen:
```
alt_ctrl_t
```

2. Docker konténer indítása (Ubuntu image) 
```bash
docker run --name sajátnevem -it ubuntu
```
